Siege Media >> USAHS

## The 2021 American Nursing Shortage: A Data Study

Open console in project's folder and type:
```bash
npm install
```

For developing:
```bash
npm start
```

To crate the deliverable project in the /dist folder:
```bash
npm run build
```
